import React from 'react';
import './App.css';
import {text, view} from 'react-native';
import Name from './Components/Name';

export default function App() {
  return (
    <view style={styles.container}>
      <Name/>
      </view>
  );

}

const styles = Stylesheet.create({
  container: {
    flex: 1,
    backgroundcolor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

