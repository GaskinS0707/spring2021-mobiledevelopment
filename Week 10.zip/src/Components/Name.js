import React, {Component} from "React";
import { StyleSheet, text, view } from 'react-native';

export default class Name extends Component {
    render() {
        return (
            <view>
                <text> Samijah Gaskin Favorite food: Pot Roast and Rice </text>
            </view>
        );
    }
}