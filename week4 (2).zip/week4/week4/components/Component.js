class Component {

  constructor (props) {
    this.props = props;
  }

}

export default Component;
