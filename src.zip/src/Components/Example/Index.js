import React from 'react';

class Example extends React.Component {
    render() {
        return <p> Hi, my name is Samijah Gaskin.</p>;
    }
}
export default Example;