import Example from './Components/Example/Index';


function App() {
  return (
    <Example/>
  );
}

export default App;
